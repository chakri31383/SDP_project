from django.urls import path
from . import views

urlpatterns =[
    path("index",views.adminpannelindex,name="adminpannelindex"),
    path("login",views.adminpannellogin,name="adminpannellogin"),
    path("Allitemsadmin",views.Allitemsadmin,name="Allitemsadmin"),
    path("AllNotDeliveredItems",views.AllNotDeliveredItems,name="AllNotDeliveredItems"),
    path("AllDeliveredItems",views.AllDeliveredItems,name="AllDeliveredItems"),
    path("AllCanceledItems",views.AllCanceledItems,name="AllCanceledItems"),
    path("Allfarmers",views.Allfarmers,name="Allfarmers"),
    path("Allusers",views.Allusers,name="Allusers"),
    path("AllRejectedfarmers",views.AllRejectedfarmers,name="AllRejectedfarmers"),
    path("AllPendingfarmers",views.AllPendingfarmers,name="AllPendingfarmers"),
    path("AllAcceptedfarmers",views.AllAcceptedfarmers,name="AllAcceptedfarmers"),
    path("farmerstatus/<int:ram>",views.farmerstatus,name="farmerstatus"),
    path("farmerdelete/<int:ram>",views.farmerdelete,name="farmerdelete"),
    path("usersdelete/<int:ram>",views.usersdelete,name="usersdelete"),
    path("adminlogout",views.adminlogout,name="adminlogout"),
    path("Feedbackreviews",views.Feedbackreviews,name="Feedbackreviews"),
]