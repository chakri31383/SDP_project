from django.conf import settings
from django.contrib.auth import logout, authenticate, login
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.shortcuts import render, redirect

from farmersapp.models import Farmer, Items

from userapp.models import Bookings

from userapp.models import UsersData

from .models import Contact


# Create your views here.
def adminpannelindex(request):
    return render(request,"adminpannelapp/adminpannelindex.html")

def adminlogout(request):
    logout(request)
    return redirect('adminpannelindex')

def adminpannellogin(request):
    if request.method=="POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user.is_superuser:
            login(request, user)
            return redirect('adminpannelindex')
    return render(request,"adminpannelapp/adminpannellogin.html")

def Allitemsadmin(request):
    if not request.user.is_authenticated:
        return redirect("adminpannellogin")
    items=Items.objects.all()
    return render(request, "adminpannelapp/Allitems.html",{"items":items})

def Allfarmers(request):
    if not request.user.is_authenticated:
        return redirect("adminpannellogin")
    farmers=Farmer.objects.all();
    return render(request, "adminpannelapp/Allfarmers.html",{"farmers":farmers})

def Allusers(request):
    if not request.user.is_authenticated:
        return redirect("adminpannellogin")
    users = UsersData.objects.all();
    return render(request, "adminpannelapp/Allusers.html", {"users": users})

def farmerstatus(request,ram):
    if not request.user.is_authenticated:
        return redirect("adminpannellogin")
    farmer=Farmer.objects.get(id=ram)
    if request.method=="POST":
        farmer.status=request.POST['status']
        farmer.save()
        # a=request.POST['status']
        # mail = farmer.user.email
        # if a=="Accepted":
        #     tosend = 'From Team SUPPORT TO FARMERS \nYou are Accepted By the team '
        # else:
        #     tosend = 'From Team SUPPORT TO FARMERS \n You are Rejectd By the team\n Better Luck next Time'
        # send_mail(
        #     'From The Team SUPPORT TO FARMERS',
        #     tosend,
        #     settings.EMAIL_HOST_USER,
        #     [mail],
        #     fail_silently=False,
        # )
        return redirect("Allfarmers")
    return render(request,"adminpannelapp/farmerstatus.html",{"farmer":farmer})

def farmerdelete(request,ram):
    if not request.user.is_authenticated:
        return redirect("adminpannellogin")
    farmer = Farmer.objects.get(id=ram)
    User.objects.get(id=farmer.user.id).delete()
    return redirect("Allfarmers")

def AllAcceptedfarmers(request):
    if not request.user.is_authenticated:
        return redirect("adminpannellogin")
    farmers=Farmer.objects.filter(status="Accepted");
    return render(request, "adminpannelapp/Allfarmers.html",{"farmers":farmers})


def AllRejectedfarmers(request):
    if not request.user.is_authenticated:
        return redirect("adminpannellogin")
    farmers=Farmer.objects.filter(status="Rejected");
    return render(request, "adminpannelapp/Allfarmers.html",{"farmers":farmers})


def AllPendingfarmers(request):
    if not request.user.is_authenticated:
        return redirect("adminpannellogin")
    farmers=Farmer.objects.filter(status="pending");
    return render(request, "adminpannelapp/Allfarmers.html",{"farmers":farmers})


def AllCanceledItems(request):
    if not request.user.is_authenticated:
        return redirect("adminpannellogin")
    itemsbooked=Bookings.objects.filter(status="Canceled").order_by('-applydate', 'applytime')
    return render(request, "adminpannelapp/AllorderedItems.html", {'items': itemsbooked})

def AllDeliveredItems(request):
    if not request.user.is_authenticated:
        return redirect("adminpannellogin")
    itemsbooked=Bookings.objects.filter(status="Delivered").order_by('-applydate', 'applytime')
    return render(request, "adminpannelapp/AllorderedItems.html", {'items': itemsbooked})

def AllNotDeliveredItems(request):
    if not request.user.is_authenticated:
        return redirect("adminpannellogin")
    itemsbooked=Bookings.objects.filter(status="Not Delivered").order_by('-applydate', 'applytime')
    return render(request, "adminpannelapp/AllorderedItems.html", {'items': itemsbooked})


def usersdelete(request,ram):
    if not request.user.is_authenticated:
        return redirect("adminpannellogin")
    us = UsersData.objects.get(id=ram)
    User.objects.get(id=us.user.id).delete()
    return redirect("Allusers")

def Feedbackreviews(request):
    if not request.user.is_authenticated:
        return redirect("adminpannellogin")
    reviews=Contact.objects.all()
    return render(request, "adminpannelapp/Feedbackreviews.html",{'reviews':reviews})