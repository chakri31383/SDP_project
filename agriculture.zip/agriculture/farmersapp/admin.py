from django.contrib import admin

from .models import Farmer, Items

admin.site.register(Farmer)
admin.site.register(Items)
