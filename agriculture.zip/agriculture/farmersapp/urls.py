from django.urls import path
from . import views

urlpatterns = [
    path("index",views.farmerhome,name="farmerindex"),
    path("farmersignup",views.farmersignup,name="farmersignup"),
    path("farmerlogin",views.farmerlogin,name="farmerlogin"),
    path("Additems",views.Additems,name="Additems"),
    path("Allitems",views.Allitems,name="Allitems"),
    path("Deleteitems/<int:pk>/",views.Deleteitems,name="Deleteitems"),
    path("Ordereditems",views.Ordereditems,name="Ordereditems"),
    path("Delivereditems",views.Delivereditems,name="Delivereditems"),
    path("Canceleditems",views.Canceleditems,name="Canceleditems"),
    path("updatestatus/<int:ram>",views.updatestatus,name="updatestatus"),
    path("Edititems/<int:pk>/",views.Edititems,name="Edititems"),
    path("logoutfarmer",views.logoutfarmer,name="logoutfarmer"),
]