from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.shortcuts import render, redirect

from .models import Farmer, Items
from userapp.models import Bookings


# Create your views here.
def farmerhome(request):
    if not request.user.is_authenticated:
        return redirect("farmerlogin")
    return render(request,'farmerapp/farmerhome.html')

def farmersignup(request):
    if(request.method=="POST"):
        lastname = request.POST['lastname']
        firstname = request.POST['firstname']
        phno = request.POST['phno']
        email = request.POST['email']
        username = request.POST['username']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']
        address = request.POST['address']
        image = request.FILES.get('image', None)
        if confirm_password==password:
            newuser = User.objects.create_user(first_name=firstname,last_name=lastname, email=email, username=username, password=password)
            newagent = Farmer.objects.create(user=newuser, phone=phno, address=address, image=image,
                                                    type="farmer", status="pending")
            newuser.save()
            newagent.save()
            return render(request, 'farmerapp/farmerhome.html',{"status":"Registration Completed"})
        else:
            return render(request, 'farmerapp/farmersignup.html',{"status":"Passwords are Not Same"})
    return render(request,'farmerapp/farmersignup.html')


def farmerlogin(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        userss = authenticate(username=username, password=password)
        if userss is not None:
            user1 = Farmer.objects.get(user=userss)
            if user1.type == "farmer" and user1.status=="Accepted":
                login(request, userss)
                return render(request, 'farmerapp/farmerhome.html', {"status": "Login Completed"})
            else:
                return render(request, 'farmerapp/farmerlogin.html', {"status": "Not Accepted"})
        else:
            return render(request, 'farmerapp/farmersignup.html', {"status": "User Not Found"})
    return render(request, 'farmerapp/farmerlogin.html')

def logoutfarmer(request):
    logout(request)
    return redirect('farmerindex')

def Additems(request):
    if not request.user.is_authenticated:
        return redirect("farmerlogin")
    if request.method=="POST":
        itemname=request.POST['itemname']
        itemprice=request.POST['itemprice']
        itemcategary=request.POST['itemcategary']
        itemdescription=request.POST['itemdescription']
        itemstockquantity=request.POST['itemstockquantity']
        itemrating=4
        itemimage = request.FILES.get('image', None)
        farmer = Farmer.objects.get(user=request.user)
        Items(farmer=farmer,itemname=itemname,itemprice=itemprice,itemimage=itemimage,itemcategary=itemcategary,itemdescription=itemdescription,itemrating=itemrating,itemstockquantity=itemstockquantity).save()
        return render(request, "farmerapp/Additems.html",{"status":"Item Added Success fully"})
    return render(request,"farmerapp/Additems.html")

def Allitems(request):
    if not request.user.is_authenticated:
        return redirect("farmerlogin")
    farmer = Farmer.objects.get(user=request.user)
    items=Items.objects.filter(farmer=farmer)
    return render(request, "farmerapp/Allitems.html",{"items":items})

def Deleteitems(request,pk):
    if not request.user.is_authenticated:
        return redirect("farmerlogin")
    Items.objects.get(id=pk).delete()
    return redirect("Allitems")

def Edititems(request,pk):
    if not request.user.is_authenticated:
        return redirect("farmerlogin")
    item=Items.objects.get(id=pk)
    if request.method =="POST":
        item.itemname = request.POST['itemname']
        item.itemprice = request.POST['itemprice']
        item.itemcategary = request.POST['itemcategary']
        item.itemdescription = request.POST['itemdescription']
        item.itemstockquantity = request.POST['itemstockquantity']
        item.itemrating = 4
        item.save();
        return redirect("Allitems")
    return render(request,"farmerapp/Edititems.html",{'item':item})



def Ordereditems(request):
    if not request.user.is_authenticated:
        return redirect("farmerlogin")
    farmer = Farmer.objects.get(user=request.user)
    itemsbooked=Bookings.objects.filter(farmer=farmer,status="Not Delivered").order_by('-applydate', 'applytime')
    return render(request, "farmerapp/Ordereditems.html", {'items': itemsbooked})


def Delivereditems(request):
    if not request.user.is_authenticated:
        return redirect("farmerlogin")
    farmer = Farmer.objects.get(user=request.user)
    itemsbooked=Bookings.objects.filter(farmer=farmer,status="Delivered").order_by('-applydate', 'applytime')
    return render(request, "farmerapp/Ordereditems.html", {'items': itemsbooked})

def Canceleditems(request):
    if not request.user.is_authenticated:
        return redirect("farmerlogin")
    farmer = Farmer.objects.get(user=request.user)
    itemsbooked=Bookings.objects.filter(farmer=farmer,status="Canceled").order_by('-applydate', 'applytime')
    return render(request, "farmerapp/Ordereditems.html", {'items': itemsbooked})

def updatestatus(request,ram):
    if not request.user.is_authenticated:
        return redirect("farmerlogin")
    booked = Bookings.objects.get(id=ram)
    booked.status = "Delivered"
    booked.save()
    return redirect("Ordereditems")